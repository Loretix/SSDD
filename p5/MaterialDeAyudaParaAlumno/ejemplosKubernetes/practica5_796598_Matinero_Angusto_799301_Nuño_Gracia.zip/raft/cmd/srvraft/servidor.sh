CGO_ENABLED=0 go build -o servidor ./main.go
mv servidor $HOME/GitHub/SSDD/p5/MaterialDeAyudaParaAlumno/ejemplosKubernetes/Dockerfiles/servidor