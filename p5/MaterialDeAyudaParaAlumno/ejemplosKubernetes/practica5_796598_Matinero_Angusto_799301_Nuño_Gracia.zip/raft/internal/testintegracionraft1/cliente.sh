CGO_ENABLED=0 go build -o cliente ./main.go
mv cliente $HOME/GitHub/SSDD/p5/MaterialDeAyudaParaAlumno/ejemplosKubernetes/Dockerfiles/cliente