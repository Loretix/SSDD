docker build . -t localhost:5001/cliente:latest
docker push localhost:5001/cliente:latest