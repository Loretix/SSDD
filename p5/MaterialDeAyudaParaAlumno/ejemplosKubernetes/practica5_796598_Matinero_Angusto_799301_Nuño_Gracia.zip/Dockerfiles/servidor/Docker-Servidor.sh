docker build . -t localhost:5001/servidor:latest
docker push localhost:5001/servidor:latest